﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Seconds_Converter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void convertButton_Click(object sender, EventArgs e)
        {

            int secondEntered;
            secondEntered = int.Parse(secondsEntered.Text);
            
            if (int.TryParse(secondsEntered.Text, out secondEntered))
            { 

            int days = secondEntered / 86400;
                int hours = (secondEntered % 86400) / 3600;
                int minutes = (secondEntered % 3600) / 60;
                int seconds = (secondEntered % 60);

                //if (int.TryParse(secondsEntered.Text, out secondEntered))

                //{

                if (days > 0)
                {
                    MessageBox.Show(String.Format("{0} days, {1} hours, {2} minutes, {3} seconds", days, hours, minutes, seconds));
                }
                else if (hours > 0)
                {
                    MessageBox.Show(String.Format("{0} hours, {1} minutes, {2} seconds", hours, minutes, seconds));
                }
                else if (minutes > 0)
                {
                    MessageBox.Show(String.Format("{0} minutes, {1} seconds", minutes, seconds));
                }
                else
                {
                    MessageBox.Show(String.Format("{0} seconds", seconds));
                }
             }
            else
            {
                MessageBox.Show("Invalid input for seconds. Please enter seconds using only whole integers.");
            }

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
